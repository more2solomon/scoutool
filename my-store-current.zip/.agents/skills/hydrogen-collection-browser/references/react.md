# React And React Router

## Contents

- Loader
- Provider
- Browse Form
- Filters
- Search Pages

Use the React binding:

```tsx
import {
  getFilterRemovalUrl,
  getSortByValue,
  isFilterInputActive,
  parseCollectionParams,
  serializeCollectionParams,
  type AvailableFilter,
  type CollectionState,
  type ProductFilter,
} from "@shopify/hydrogen";
import { CollectionProvider, useCollection, useCollectionForm } from "@shopify/hydrogen/react";
import type { ProductFilter as StorefrontApiProductFilter } from "@shopify/hydrogen/storefront-api-types";
```

Use `getSortByValue(...)` for option values so the `sort_by` query param round-trips through `parseCollectionParams()`:

```ts
const COLLECTION_SORT_OPTIONS = [
  { label: "Featured", value: getSortByValue("COLLECTION_DEFAULT", false) },
  { label: "Best selling", value: getSortByValue("BEST_SELLING", false) },
  { label: "Alphabetically, A-Z", value: getSortByValue("TITLE", false) },
  { label: "Alphabetically, Z-A", value: getSortByValue("TITLE", true) },
  { label: "Price, low to high", value: getSortByValue("PRICE", false) },
  { label: "Price, high to low", value: getSortByValue("PRICE", true) },
  { label: "Date, old to new", value: getSortByValue("CREATED", false) },
  { label: "Date, new to old", value: getSortByValue("CREATED", true) },
];

const SEARCH_SORT_OPTIONS = [
  { label: "Relevance", value: getSortByValue("RELEVANCE", false) },
  { label: "Price, low to high", value: getSortByValue("PRICE", false) },
  { label: "Price, high to low", value: getSortByValue("PRICE", true) },
];
```

## Loader

In a route loader, parse the current URL and query the Storefront API with the parsed browse state:

```ts
export async function loader({ context, params, request }: Route.LoaderArgs) {
  const storefrontClient = context.get(storefrontClientContext);
  const url = new URL(request.url);
  const browse = parseCollectionParams(url.searchParams);

  const { data } = await storefrontClient.graphql(COLLECTION_QUERY, {
    variables: {
      handle: params.handle,
      first: 24,
      filters:
        browse.filters.length > 0 ? (browse.filters as StorefrontApiProductFilter[]) : undefined,
      sortKey: browse.sortKey,
      reverse: browse.reverse || undefined,
    },
  });

  if (!data?.collection) throw new Response("Collection not found", { status: 404 });

  return {
    collection: data.collection,
    products: data.collection.products.nodes,
    availableFilters: data.collection.products.filters,
    dataSearch: url.searchParams.toString(),
  };
}
```

Keep `dataSearch` exactly aligned with the query used for the server data.

## Provider

Wrap the browse UI in `CollectionProvider` and let it own filter/sort intent:

```tsx
export default function CollectionRoute({ loaderData }: Route.ComponentProps) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  return (
    <CollectionProvider
      data={{ handle: loaderData.collection.handle, dataSearch: loaderData.dataSearch }}
      urlSearch={searchParams.toString()}
      onChange={(search) =>
        navigate(
          { search },
          {
            replace: searchParams.size > 0,
            preventScrollReset: true,
          },
        )
      }
    >
      <CollectionPage {...loaderData} />
    </CollectionProvider>
  );
}
```

## Browse Form

Inside the browse UI:

```tsx
function CollectionPage({ availableFilters, products }: Props) {
  const state = useCollection();
  const { formProps } = useCollectionForm();
  const isLoading = state.status === "loading";

  return (
    <form {...formProps()} method="get" action={collectionPath} className="browse">
      <FilterSidebar
        availableFilters={availableFilters}
        activeFilters={state.filters}
        disabled={isLoading}
      />
      <select name="sort_by" defaultValue={currentSortValue(state)} onChange={requestFormSubmit}>
        {COLLECTION_SORT_OPTIONS.map((option) => (
          <option key={option.label} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      <ProductGrid products={products} pending={isLoading} />
    </form>
  );
}

function requestFormSubmit(event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
  event.currentTarget.form?.requestSubmit();
}
```

Pass `method="get"` and an explicit `action={collectionPath}` (the current `/collections/:handle` or `/search` route URL) literally — `formProps()` only wires the submit handler (see the SKILL.md UI rule).

Use uncontrolled form controls. When a route needs to remount them after external navigation, put `key={serializeCollectionParams({ filters: state.filters, sortKey: undefined, reverse: false }).toString()}` on the filter subtree (for search, include the term in the key) — keyed by serialized **filter state**, not the live URL. The URL clears before the `CollectionProvider` reconciler settles `state.filters`, so a URL-keyed remount bakes in stale defaults. This resets checkbox and price-input DOM state without coupling active filter chips to the form remount.

## Filters

Choose the control at the filter-group level. `PRICE_RANGE` uses min/max number inputs; `LIST` and `BOOLEAN` use checkboxes. Do not use the number of serialized entries to choose the control—a price value serializes to both `gte` and `lte`.

```tsx
function FilterGroup({
  activeFilters,
  filter,
}: {
  activeFilters: ProductFilter[];
  filter: AvailableFilter;
}) {
  if (filter.type === "PRICE_RANGE") {
    return <PriceRangeInput activeFilters={activeFilters} />;
  }

  return filter.values.map((value) => (
    <CheckboxFilterValue
      key={value.id}
      activeFilters={activeFilters}
      filter={filter}
      value={value}
    />
  ));
}

function PriceRangeInput({ activeFilters }: { activeFilters: ProductFilter[] }) {
  const price = activeFilters.find((filter) => filter.price)?.price;
  return (
    <>
      <PriceInput name="filter.v.price.gte" defaultValue={price?.min} label="Minimum price" />
      <PriceInput name="filter.v.price.lte" defaultValue={price?.max} label="Maximum price" />
    </>
  );
}

function PriceInput({ name, defaultValue, label }: { name: string; defaultValue?: number; label: string }) {
  const initialValue = defaultValue == null ? "" : String(defaultValue);
  return (
    <input
      type="number"
      name={name}
      defaultValue={defaultValue}
      aria-label={label}
      min="0"
      step="any"
      onBlur={(event) => {
        if (event.currentTarget.value !== initialValue) {
          event.currentTarget.form?.requestSubmit();
        }
      }}
      onKeyDown={(event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          event.currentTarget.blur();
        }
      }}
    />
  );
}

function filterValueInputParamEntries(input: string): Array<{ name: string; value: string }> {
  let filter: ProductFilter;
  try {
    filter = JSON.parse(input) as ProductFilter;
  } catch {
    return [];
  }

  return Array.from(
    serializeCollectionParams({ filters: [filter], sortKey: undefined, reverse: false }),
    ([name, value]) => ({ name, value }),
  );
}

function CheckboxFilterValue({
  activeFilters,
  filter,
  value,
}: {
  activeFilters: ProductFilter[];
  filter: AvailableFilter;
  value: AvailableFilter["values"][number];
}) {
  const entries = filterValueInputParamEntries(value.input);
  if (entries.length !== 1) return null;

  const [{ name, value: paramValue }] = entries;

  return (
    <input
      type="checkbox"
      name={name}
      value={paramValue}
      defaultChecked={isFilterInputActive(activeFilters, value.input)}
      onChange={(event) => {
        if (isMutuallyExclusive(filter) && event.currentTarget.checked) {
          uncheckSiblings(event.currentTarget);
        }
        requestFormSubmit(event);
      }}
    />
  );
}
```

Use `filter.type` only to choose the control shape. For checkbox values, keep `filterValueInputParamEntries` as thin app glue: `JSON.parse(value.input)` plus `serializeCollectionParams(...)`. Do not derive checkbox params from IDs, labels, or filter types.

For active chips, use parsed active `ProductFilter` values from collection state:

```tsx
function ActiveFilterChip({ collectionPath, filter, state }: Props) {
  const currentParams = serializeCollectionParams(state);
  const removal = getFilterRemovalUrl(currentParams, filter);
  const href = removal === "?" ? collectionPath : `${collectionPath}${removal}`;

  return (
    <a href={href}>
      {describeFilter(filter)}
    </a>
  );
}
```

When passing `browse.filters` into a `gql()` query variable typed from Storefront API introspection, match the app's established pattern. The Hydrogen examples cast the parsed filters to the generated Storefront API `ProductFilter` type at the query variable boundary:

```ts
import type { ProductFilter as StorefrontApiProductFilter } from "@shopify/hydrogen/storefront-api-types";

variables: {
  filters:
    browse.filters.length > 0 ? (browse.filters as StorefrontApiProductFilter[]) : undefined,
}
```

Keep this as a generated-type cast scoped to the query variable boundary.

## Search Pages

Use the same binding with a synthetic handle:

```tsx
<CollectionProvider
  data={{ handle: `search:${term}`, dataSearch }}
  urlSearch={searchParams.toString()}
  onChange={(search) => navigate({ search }, { replace: searchParams.size > 0 })}
>
  <input type="hidden" name="q" value={term} />
</CollectionProvider>
```

When the search term changes, include it in the browse form `key` so old unchecked/checked inputs do not carry over.
