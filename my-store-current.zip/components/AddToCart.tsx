"use client";

import {useState} from "react";

type CartResponse = {
  id: string;
  checkoutUrl: string;
  totalQuantity: number;
};

export default function AddToCart({
  merchandiseId,
  label = "Add to cart",
}: {
  merchandiseId?: string;
  label?: string;
}) {
  const [loading, setLoading] = useState(false);

  async function add() {
    if (!merchandiseId || loading) return;

    setLoading(true);

    try {
      const existing = localStorage.getItem("vj_cart_id") || undefined;

      const response = await fetch("/api/cart", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
          cartId: existing,
          merchandiseId,
          quantity: 1,
        }),
      });

      const cart: CartResponse = await response.json();

      if (!response.ok) {
        throw new Error("Cart request failed");
      }

      localStorage.setItem("vj_cart_id", cart.id);
      localStorage.setItem("vj_checkout_url", cart.checkoutUrl);
      localStorage.setItem(
        "vj_cart_quantity",
        String(cart.totalQuantity || 0),
      );

      window.dispatchEvent(new Event("vj-cart-updated"));
    } catch (error) {
      alert("Could not add this product to cart. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button className="charge-button" onClick={add} disabled={!merchandiseId || loading}>
      {loading ? "Adding…" : label}
    </button>
  );
}
