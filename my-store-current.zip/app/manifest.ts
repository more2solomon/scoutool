import type {MetadataRoute} from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Velvet Journal Co",
    short_name: "Velvet Journal",
    description:
      "Journals and planners for gratitude, goals, mindfulness and intentional living.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#f4ede7",
    icons: [
      {
        src: "/charge-media/ChatGPT_Image_Jun_5_2026_06_21_36_AM.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  };
}
