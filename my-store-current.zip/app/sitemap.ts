import type {MetadataRoute} from "next";
import {
  getAllProducts,
  getCollections,
  getPages,
  getPolicies,
  getArticles,
} from "@/lib/shopify";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl =
    process.env.NEXT_PUBLIC_SITE_URL || "https://www.velvetjournalco.store";

  const now = new Date();

  const base: MetadataRoute.Sitemap = [
    {url: siteUrl, lastModified: now, changeFrequency: "daily", priority: 1},
    {
      url: `${siteUrl}/collections/all`,
      lastModified: now,
      changeFrequency: "daily",
      priority: 0.9,
    },
    {
      url: `${siteUrl}/pages/contact`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.6,
    },
    {
      url: `${siteUrl}/blogs`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.7,
    },
  ];

  try {
    const [products, collections, pages, policies, articles] =
      await Promise.all([
        getAllProducts(),
        getCollections(),
        getPages(),
        getPolicies(),
        getArticles(),
      ]);

    return [
      ...base,
      ...products.map((p) => ({
        url: `${siteUrl}/products/${p.handle}`,
        lastModified: now,
        changeFrequency: "weekly" as const,
        priority: 0.8,
      })),
      ...collections.map((c) => ({
        url: `${siteUrl}/collections/${c.handle}`,
        lastModified: now,
        changeFrequency: "weekly" as const,
        priority: 0.75,
      })),
      ...pages
        .filter((p) => p.handle !== "contact")
        .map((p) => ({
          url: `${siteUrl}/pages/${p.handle}`,
          lastModified: now,
          changeFrequency: "monthly" as const,
          priority: 0.6,
        })),
      ...policies.map((p) => ({
        url: `${siteUrl}/policies/${p.handle}`,
        lastModified: now,
        changeFrequency: "yearly" as const,
        priority: 0.3,
      })),
      ...articles.map((a) => ({
        url: `${siteUrl}/blogs/${a.blogHandle}/${a.handle}`,
        lastModified: new Date(a.publishedAt),
        changeFrequency: "monthly" as const,
        priority: 0.65,
      })),
    ];
  } catch {
    return base;
  }
}
