export default function Footer() {
  return (
    <>
      <section className="service-strip bottom-service">
        <div className="charge-shell service-grid">
          <div><b>🚚 FREE SHIPPING</b><span>Free for orders over $100</span></div>
          <div><b>◷ 24/7 Support</b><span>Fast, professional support</span></div>
          <div><b>▣ CHOOSE DELIVERY DATE</b><span>Flexible delivery date</span></div>
          <div><b>☑ EXTENDED SUPPORT PERIOD</b><span>30 days return policy</span></div>
        </div>
      </section>

      <footer className="charge-footer">
        <div className="charge-shell footer-grid">
          <div>
            <h4>◉ &nbsp; Address</h4>
            <p>Online Store<br/>Worldwide Shipping</p>
          </div>

          <div>
            <h4>✉ &nbsp; Email</h4>
            <p><a href="mailto:gnewton581@gmail.com">gnewton581@gmail.com</a></p>
          </div>

          <div>
            <h4>Newsletter</h4>
            <form className="newsletter">
              <input type="email" placeholder="Your Email..." aria-label="Newsletter email" />
              <button type="button">›</button>
            </form>
          </div>
        </div>
      </footer>

      <div className="footer-bottom">
        <div className="charge-shell footer-bottom-inner">
          <span>© Velvet Journal Co</span>
          <div>
            <a href="/search">Search</a>
            <a href="/policies/privacy-policy">Your Privacy Choices</a>
            <a href="/collections/all">Shop</a>
          </div>
        </div>
      </div>
    </>
  );
}
