VELVET JOURNAL NEXT.JS STOREFRONT PATCH

Apply from:
/workspaces/scoutool/shopify-hydrogen/my-store

1) Back up app:
   cp -a app ../my-store-app-backup

2) Unzip this patch into the project root.

3) Ensure public/charge-media already contains the captured Shopify images.

4) Ensure .env.local contains:
   PUBLIC_STORE_DOMAIN
   PRIVATE_STOREFRONT_API_TOKEN

5) Build:
   npm run build

6) Add the same environment variables to Vercel Production,
   then:
   npx vercel@latest --prod

The patch adds:
- Charge-style homepage
- Catalog
- Contact
- Product pages
- Cart creation/add-to-cart with Shopify checkout
- Account placeholder
- Search redirect
- Footer/contact email without phone
