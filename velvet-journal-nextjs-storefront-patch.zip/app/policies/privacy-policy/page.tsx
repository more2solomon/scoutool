import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Privacy() {
  return (
    <>
      <Header />
      <main className="charge-shell simple-page">
        <h1>Privacy Policy</h1>
        <p>
          Storefront commerce, customer-account, cart, checkout and order information
          are processed through Shopify. This page should be replaced with your
          final Shopify privacy-policy text before launch.
        </p>
      </main>
      <Footer />
    </>
  );
}
