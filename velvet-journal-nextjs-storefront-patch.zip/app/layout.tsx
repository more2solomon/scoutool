import type {Metadata} from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Velvet Journal Co",
    template: "%s | Velvet Journal Co",
  },
  description:
    "Beautiful journals and planners for mindfulness, gratitude, productivity and personal growth.",
  icons: {
    icon: "/charge-media/ChatGPT_Image_Jun_5_2026_06_21_36_AM.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{children: React.ReactNode}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
