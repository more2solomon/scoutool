import {NextRequest, NextResponse} from "next/server";
import {shopifyFetch} from "@/lib/shopify";

const CART_FIELDS = `
  id
  checkoutUrl
  totalQuantity
`;

export async function POST(request: NextRequest) {
  try {
    const {
      cartId,
      merchandiseId,
      quantity = 1,
    } = await request.json();

    if (!merchandiseId) {
      return NextResponse.json(
        {error: "Missing merchandiseId"},
        {status: 400},
      );
    }

    if (cartId) {
      const data = await shopifyFetch<{
        cartLinesAdd: {
          cart: {
            id: string;
            checkoutUrl: string;
            totalQuantity: number;
          };
          userErrors: Array<{message: string}>;
        };
      }>(
        `mutation AddLine($cartId: ID!, $lines: [CartLineInput!]!) {
          cartLinesAdd(cartId: $cartId, lines: $lines) {
            cart { ${CART_FIELDS} }
            userErrors { message }
          }
        }`,
        {
          cartId,
          lines: [{merchandiseId, quantity}],
        },
      );

      if (data.cartLinesAdd.userErrors.length) {
        throw new Error(data.cartLinesAdd.userErrors[0].message);
      }

      return NextResponse.json(data.cartLinesAdd.cart);
    }

    const data = await shopifyFetch<{
      cartCreate: {
        cart: {
          id: string;
          checkoutUrl: string;
          totalQuantity: number;
        };
        userErrors: Array<{message: string}>;
      };
    }>(
      `mutation CreateCart($input: CartInput!) {
        cartCreate(input: $input) {
          cart { ${CART_FIELDS} }
          userErrors { message }
        }
      }`,
      {
        input: {
          lines: [{merchandiseId, quantity}],
        },
      },
    );

    if (data.cartCreate.userErrors.length) {
      throw new Error(data.cartCreate.userErrors[0].message);
    }

    return NextResponse.json(data.cartCreate.cart);
  } catch (error) {
    return NextResponse.json(
      {error: error instanceof Error ? error.message : "Cart failed"},
      {status: 500},
    );
  }
}
