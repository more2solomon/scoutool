import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AddToCart from "@/components/AddToCart";
import {getProduct, money} from "@/lib/shopify";
import {notFound} from "next/navigation";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{handle: string}>;
}) {
  const {handle} = await params;
  const product = await getProduct(handle);

  if (!product) notFound();

  const price = product.priceRange.minVariantPrice;
  const variant = product.variants.nodes.find((v) => v.availableForSale) || product.variants.nodes[0];

  return (
    <>
      <Header />
      <div className="breadcrumb charge-shell">
        <a href="/">Home</a> › <a href="/collections/all">Products</a> › <span>{product.title}</span>
      </div>

      <main className="charge-shell product-page">
        <div className="product-page-image">
          {product.featuredImage && (
            <img
              src={product.featuredImage.url}
              alt={product.featuredImage.altText || product.title}
            />
          )}
        </div>

        <div className="product-page-copy">
          <span className="vendor">{product.vendor || "Velvet Journal Co"}</span>
          <h1>{product.title}</h1>
          <div className="product-page-price">
            {money(price.amount, price.currencyCode)}
          </div>
          <p>{product.description}</p>
          <AddToCart merchandiseId={variant?.id} label="Add to cart" />
          <p className="checkout-note">Checkout and billing are securely handled by Shopify.</p>
        </div>
      </main>

      <Footer />
    </>
  );
}
