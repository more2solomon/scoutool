const API_VERSION = "2026-07";

function storeDomain() {
  return (process.env.PUBLIC_STORE_DOMAIN || "")
    .replace(/^https?:\/\//, "")
    .replace(/\/$/, "");
}

function privateToken() {
  return process.env.PRIVATE_STOREFRONT_API_TOKEN || "";
}

export async function shopifyFetch<T>(
  query: string,
  variables: Record<string, unknown> = {},
): Promise<T> {
  const domain = storeDomain();
  const token = privateToken();

  if (!domain || !token) {
    throw new Error(
      "Missing PUBLIC_STORE_DOMAIN or PRIVATE_STOREFRONT_API_TOKEN",
    );
  }

  const response = await fetch(
    `https://${domain}/api/${API_VERSION}/graphql.json`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Shopify-Storefront-Private-Token": token,
      },
      body: JSON.stringify({query, variables}),
      cache: "no-store",
    },
  );

  const body = await response.json();

  if (!response.ok || body.errors) {
    throw new Error(JSON.stringify(body.errors || body));
  }

  return body.data as T;
}

export type Product = {
  id: string;
  title: string;
  handle: string;
  description: string;
  vendor: string;
  featuredImage?: {
    url: string;
    altText?: string | null;
  } | null;
  priceRange: {
    minVariantPrice: {
      amount: string;
      currencyCode: string;
    };
  };
  variants: {
    nodes: Array<{
      id: string;
      availableForSale: boolean;
      title: string;
    }>;
  };
};

export async function getProducts(first = 24): Promise<Product[]> {
  const data = await shopifyFetch<{
    products: {nodes: Product[]};
  }>(
    `query Products($first: Int!) {
      products(first: $first, sortKey: CREATED_AT, reverse: true) {
        nodes {
          id
          title
          handle
          description
          vendor
          featuredImage { url altText }
          priceRange {
            minVariantPrice { amount currencyCode }
          }
          variants(first: 1) {
            nodes { id availableForSale title }
          }
        }
      }
    }`,
    {first},
  );

  return data.products.nodes;
}

export async function getProduct(handle: string): Promise<Product | null> {
  const data = await shopifyFetch<{
    product: Product | null;
  }>(
    `query Product($handle: String!) {
      product(handle: $handle) {
        id
        title
        handle
        description
        vendor
        featuredImage { url altText }
        priceRange {
          minVariantPrice { amount currencyCode }
        }
        variants(first: 20) {
          nodes { id availableForSale title }
        }
      }
    }`,
    {handle},
  );

  return data.product;
}

export function money(amount: string, currencyCode: string) {
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currencyCode,
    }).format(Number(amount));
  } catch {
    return `${currencyCode} ${amount}`;
  }
}
