import type {Metadata} from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AddToCart from "@/components/AddToCart";
import BuyNow from "@/components/BuyNow";
import {getProduct, money} from "@/lib/shopify";
import {notFound} from "next/navigation";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{handle: string}>;
}): Promise<Metadata> {
  const {handle} = await params;
  const product = await getProduct(handle);
  if (!product) return {};

  return {
    title: product.seo?.title || product.title,
    description:
      product.seo?.description ||
      product.description ||
      `Shop ${product.title} from Velvet Journal Co.`,
    alternates: {
      canonical: `/products/${product.handle}`,
    },
  };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{handle: string}>;
}) {
  const {handle} = await params;
  const product = await getProduct(handle);

  if (!product) notFound();

  const price = product.priceRange.minVariantPrice;

  return (
    <>
      <Header />

      <div className="breadcrumb charge-shell">
        <a href="/">Home</a>
        <span>›</span>
        <a href="/collections/all">Products</a>
        <span>›</span>
        <span>{product.title}</span>
      </div>

      <main className="charge-shell product-page">
        <div className="product-page-image">
          {product.featuredImage && (
            <img
              src={product.featuredImage.url}
              alt={product.featuredImage.altText || product.title}
            />
          )}
        </div>

        <div className="product-page-copy">
          <span className="vendor">
            {product.vendor || "Velvet Journal Co"}
          </span>

          <h1>{product.title}</h1>

          <div className="product-page-price">
            {money(price.amount, price.currencyCode)}
          </div>

          {product.descriptionHtml ? (
            <div
              className="rich-text"
              dangerouslySetInnerHTML={{
                __html: product.descriptionHtml,
              }}
            />
          ) : (
            <p>{product.description}</p>
          )}

          <div className="product-actions">
            <AddToCart
              handle={product.handle}
              title={product.title}
              price={Number(price.amount)}
              currency={price.currencyCode}
              image={product.featuredImage?.url}
              label="Add to cart"
            />

            <BuyNow handle={product.handle} />
          </div>

          <p className="checkout-note">
            Checkout is handled on Velvet Journal Co. Payment is currently unavailable while configuration is completed.
          </p>
        </div>
      </main>

      <Footer />
    </>
  );
}
