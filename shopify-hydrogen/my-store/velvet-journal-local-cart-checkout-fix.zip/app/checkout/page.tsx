"use client";

import {useEffect, useMemo, useState} from "react";
import {useSearchParams} from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import type {LocalCartLine} from "@/components/AddToCart";

const CART_KEY = "vj_local_cart";

function CheckoutContent() {
  const params = useSearchParams();
  const directProduct = params.get("product");
  const [cart, setCart] = useState<LocalCartLine[]>([]);

  useEffect(() => {
    try {
      const stored: LocalCartLine[] = JSON.parse(
        localStorage.getItem(CART_KEY) || "[]",
      );

      if (directProduct && !stored.some((line) => line.handle === directProduct)) {
        // Buy Now keeps the user inside the site. If the product was already added,
        // it is shown from the local cart; otherwise product selection can continue
        // without any Shopify redirect.
      }

      setCart(stored);
    } catch {
      setCart([]);
    }
  }, [directProduct]);

  const subtotal = useMemo(
    () =>
      cart.reduce(
        (sum, line) =>
          sum + Number(line.price) * Number(line.quantity),
        0,
      ),
    [cart],
  );

  return (
    <>
      <Header />

      <main className="charge-shell checkout-page">
        <section>
          <div className="breadcrumb">
            <a href="/">Home</a>
            <span>›</span>
            <a href="/cart">Cart</a>
            <span>›</span>
            <span>Checkout</span>
          </div>

          <h1>Checkout</h1>

          <p className="checkout-intro">
            Enter your contact and delivery information below.
          </p>

          <form className="checkout-form">
            <h2>Contact</h2>

            <label>
              Email*
              <input
                required
                type="email"
                name="email"
                placeholder="Email"
              />
            </label>

            <h2>Delivery</h2>

            <div className="checkout-two">
              <label>
                First name*
                <input required name="firstName" />
              </label>

              <label>
                Last name*
                <input required name="lastName" />
              </label>
            </div>

            <label>
              Address*
              <input required name="address" />
            </label>

            <label>
              Apartment, suite, etc. (optional)
              <input name="apartment" />
            </label>

            <div className="checkout-three">
              <label>
                City*
                <input required name="city" />
              </label>

              <label>
                State / Region*
                <input required name="state" />
              </label>

              <label>
                Postal code*
                <input required name="postalCode" />
              </label>
            </div>

            <label>
              Country / Region*
              <input required name="country" />
            </label>

            <h2>Payment</h2>

            <div className="payment-placeholder">
              <div className="payment-placeholder-icon">P</div>

              <h3>Secure payment</h3>

              <p>
                Payment integration is being configured.
              </p>

              <p className="payment-small">
                Your order will remain on Velvet Journal Co. You will not be redirected to Shopify.
              </p>

              <button
                type="button"
                className="payment-disabled-button"
                disabled
              >
                Payments temporarily unavailable
              </button>
            </div>
          </form>
        </section>

        <aside className="checkout-summary">
          <h2>Order summary</h2>

          {!cart.length ? (
            <div className="checkout-empty">
              <p>Your cart is currently empty.</p>
              <a href="/collections/all">Return to products</a>
            </div>
          ) : (
            <>
              {cart.map((line) => (
                <div className="checkout-summary-product" key={line.handle}>
                  {line.image && <img src={line.image} alt="" />}

                  <div>
                    <strong>{line.title}</strong>
                    <span>Qty {line.quantity}</span>
                  </div>

                  <strong>
                    {line.currency}{" "}
                    {(line.price * line.quantity).toFixed(2)}
                  </strong>
                </div>
              ))}

              <div className="checkout-summary-line">
                <span>Subtotal</span>
                <strong>USD {subtotal.toFixed(2)}</strong>
              </div>

              <div className="checkout-summary-line">
                <span>Shipping</span>
                <span>Calculated later</span>
              </div>

              <div className="checkout-summary-total">
                <strong>Total</strong>
                <strong>USD {subtotal.toFixed(2)}</strong>
              </div>
            </>
          )}
        </aside>
      </main>

      <Footer />
    </>
  );
}

import {Suspense} from "react";

export default function CheckoutPage() {
  return (
    <Suspense fallback={<main className="charge-shell simple-page">Loading checkout…</main>}>
      <CheckoutContent />
    </Suspense>
  );
}
