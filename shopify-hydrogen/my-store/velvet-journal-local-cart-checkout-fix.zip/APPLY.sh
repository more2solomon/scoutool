#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "Removing old Shopify checkout routes..."
rm -rf app/api/cart
rm -rf app/api/buy-now

echo "Keeping Paystack backend code untouched."
echo "Installing local cart/checkout styles..."
cat app/cart-checkout-404.css >> app/globals.css
rm app/cart-checkout-404.css

echo "Checking for Shopify checkout redirects..."
if grep -RniE 'checkoutUrl|myshopify\.com.*checkout|window\.location.*shopify|vj_checkout_url' \
  app components 2>/dev/null; then
  echo
  echo "NOTE: matches above should only be comments/cleanup keys, not redirects."
fi

rm -rf .next

echo "Building..."
npm run build

echo
echo "✅ Local cart + local checkout + animated 404 installed."
echo "Deploy with: npx vercel@latest --prod"
