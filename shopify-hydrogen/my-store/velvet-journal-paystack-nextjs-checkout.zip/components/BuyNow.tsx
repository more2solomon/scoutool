"use client";

import {useRouter} from "next/navigation";

export default function BuyNow({
  handle,
  merchandiseId: _merchandiseId,
}: {
  handle?: string;
  merchandiseId?: string;
}) {
  const router = useRouter();

  function checkout() {
    let productHandle = handle;

    if (!productHandle && typeof window !== "undefined") {
      const match = window.location.pathname.match(/^\/products\/([^/]+)/);
      productHandle = match?.[1];
    }

    if (!productHandle) {
      alert("Unable to identify this product.");
      return;
    }

    router.push(`/checkout?product=${encodeURIComponent(productHandle)}`);
  }

  return (
    <button type="button" className="buy-now-button" onClick={checkout}>
      Buy now
    </button>
  );
}
