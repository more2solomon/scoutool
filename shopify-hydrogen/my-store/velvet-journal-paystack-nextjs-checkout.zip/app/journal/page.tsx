import Header from "@/components/Header";
import Footer from "@/components/Footer";

const posts = [
  ["How to Start a Gratitude Journal","A simple way to build a gratitude practice you can realistically keep.","Journal_intro_page.jpg"],
  ["Turn Big Goals Into Weekly Actions","Use your journal to turn ambitious goals into clear weekly steps.","BulletJournalGoals.jpg"],
  ["Journaling for a Calmer Daily Routine","A short reflection routine for organising your thoughts and priorities.","The6BenefitsofJournalingforMentalHealth_Aesthetically.jpg"],
];

export default function JournalPage() {
  return (
    <>
      <Header/>
      <main className="charge-shell editorial-page">
        <p className="editorial-kicker">THE VELVET JOURNAL</p>
        <h1>Ideas for a More Intentional Life</h1>
        <div className="blog-grid">
          {posts.map(([title,excerpt,image]) => (
            <article className="blog-card" key={title}>
              <img src={`/charge-media/${image}`} alt={title}/>
              <div><small>VELVET JOURNAL CO</small><h2>{title}</h2><p>{excerpt}</p></div>
            </article>
          ))}
        </div>
      </main>
      <Footer/>
    </>
  );
}
