"use client";

import {useEffect,useState} from "react";
import {useSearchParams} from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function SuccessPage() {
  const search = useSearchParams();
  const reference = search.get("reference") || search.get("trxref") || "";
  const [status,setStatus] = useState<"checking"|"success"|"failed">("checking");

  useEffect(() => {
    if (!reference) { setStatus("failed"); return; }
    fetch(`/api/paystack/verify?reference=${encodeURIComponent(reference)}`)
      .then(r => r.json())
      .then(r => setStatus(r.ok ? "success" : "failed"))
      .catch(() => setStatus("failed"));
  },[reference]);

  return (
    <>
      <Header/>
      <main className="charge-shell simple-page">
        {status === "checking" && <><h1>Confirming payment…</h1><p>Please keep this page open.</p></>}
        {status === "success" && <><h1>Payment confirmed</h1><p>Thank you for your order.</p><p>Reference: <strong>{reference}</strong></p></>}
        {status === "failed" && <><h1>Payment not confirmed</h1><p>If you were charged, email gnewton581@gmail.com with your payment reference.</p></>}
      </main>
      <Footer/>
    </>
  );
}
