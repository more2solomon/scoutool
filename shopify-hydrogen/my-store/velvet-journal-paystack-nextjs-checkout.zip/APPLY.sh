#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

rm -rf app/api/buy-now
cat app/paystack-styles.css >> app/globals.css
rm app/paystack-styles.css

npm run build

echo
echo "Build finished."
echo "Next add PAYSTACK_SECRET_KEY and PAYSTACK_CURRENCY to Vercel, then deploy."
